Estos son cronómetros para usar en Certificación de Idiomas de Asturias.
Puede descargarse una copia y usarla en local, o en vivo a través de https://ajimenezmunoz.github.io/CerCronos/
Sugerencias a antoniojjm@educastur.org
